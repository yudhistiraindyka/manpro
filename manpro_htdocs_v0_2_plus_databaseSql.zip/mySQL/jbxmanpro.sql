-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2020 at 11:53 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jbxmanpro`
--

-- --------------------------------------------------------

CREATE DATABASE jbxmanpro;

--
-- Table structure for table `cart_item`
--

CREATE TABLE `cart_item` (
  `id` int(11) NOT NULL,
  `bookTitle` varchar(180) NOT NULL,
  `bookAuthor` varchar(180) NOT NULL,
  `bookPublisher` varchar(180) NOT NULL,
  `bookPrice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart_item`
--

INSERT INTO `cart_item` (`id`, `bookTitle`, `bookAuthor`, `bookPublisher`, `bookPrice`) VALUES
(1, 'The Stranger', 'Albert Camus', 'Publisher X', 50000),
(2, 'The Lorax', 'Dr. Seuss', 'Publisher Z', 65000),
(3, 'Confetti Girl', 'Diana Lopez', 'Publisher A', 180000),
(4, 'Kimia Dasar', 'Lewis', 'Penerbit Boston', 250000),
(5, 'Vuku', 'Mimer FB', 'Ngakak Kocak 36', 69420),
(6, 'Karisma Manusia', 'Muhammad Hamzah', 'Penerbit Boston', 50000),
(7, 'Suku', 'Imanuel', 'Penerbit Astra', 50000),
(8, 'Kebahagiaan', 'Sunzu', 'Penerbit Haika', 215000);

-- --------------------------------------------------------

--
-- Table structure for table `on_sale`
--

CREATE TABLE `on_sale` (
  `id` int(11) NOT NULL,
  `bookTitle` varchar(180) NOT NULL,
  `bookAuthor` varchar(180) NOT NULL,
  `bookPublisher` varchar(180) NOT NULL,
  `bookPrice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `on_sale`
--

INSERT INTO `on_sale` (`id`, `bookTitle`, `bookAuthor`, `bookPublisher`, `bookPrice`) VALUES
(1, 'Manusia Bumi', 'Raka Wibawa', 'Penerbit Erlangga', 500000),
(2, 'Bekas Luka', 'Munarman', 'Penerbit Astra', 50000),
(3, 'Matematika Dasar', 'Marthen Kanginan', 'Penerbit Erlangga', 125000),
(4, 'Fisika Dasar', 'Giancolli', 'Penerbit Erlangga', 120000),
(5, 'Air Mata', 'Siti Nurbaya', 'Penerbit Erlangga', 50000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart_item`
--
ALTER TABLE `cart_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `on_sale`
--
ALTER TABLE `on_sale`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart_item`
--
ALTER TABLE `cart_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `on_sale`
--
ALTER TABLE `on_sale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
