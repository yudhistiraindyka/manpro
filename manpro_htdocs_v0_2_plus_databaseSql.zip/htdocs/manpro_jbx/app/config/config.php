<?php

define('BASEURL', 'http://localhost/manpro_jbx/public');

// Database Definition Constants
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'jbxmanpro');


?>