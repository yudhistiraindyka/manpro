<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="utf-8">

	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="<?= BASEURL; ?>/style/style.css">
    <link rel="stylesheet" href="<?= BASEURL; ?>/fontawesome/css/all.css">

	<title><?= $data['judul']; ?></title>
</head>
<body class="bg-laurel">
	<!-- navbar -->
    <nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-sealbrown">
      <div class="container-fluid">
        
        <a href="<?= BASEURL; ?>" class="navbar-brand text-celadon">
          <h2><i class="fas fa-home"></i></h2>
        </a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <form class="form-inline">
            <input type="search" class="form-control mr-sm-2" placeholder="Search" style="width: 17rem;">
            <button class="btn btn-search my-2 my-sm-0" type="submit"><i class="fas fa-search"></i></button>
          </form>
          <ul class="navbar-nav mr-auto" style="margin-top: 15px; margin-bottom: 15px;">
            <li class="nav-item"><a class="top-bar-text" href="<?= BASEURL; ?>/sell">Sell Now!</a></li>
            <li class="nav-item"><a class="top-bar-text" href="<?= BASEURL; ?>/cart">Cart</a></li>
            <li class="nav-item"><a class="top-bar-text" href="<?= BASEURL; ?>/about">About Us</a></li>
          </ul>
          <ul class="navbar-nav">
            <li class="nav-item">
              <a href="<?= BASEURL; ?>/login" class="top-bar-text">Login/Register</a>
            </li>
          </ul>
        </div>

      </div>
    </nav>
    <!-- (Akhir) navbar -->