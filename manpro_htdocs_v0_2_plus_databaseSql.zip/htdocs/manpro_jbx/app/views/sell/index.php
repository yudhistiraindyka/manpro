    <!-- Sell -->
    <section class="sell">
    	<div class="container">
    		<div class="row" style="margin-top: 30px;">
    			<div class="col-md-12">
                    <h2 class="text-sealbrown text-center">Sell</h2>
                    <hr>
                </div>
            </div>
            <div class="row" style="margin-top: 30px; margin-bottom: 15px;">
    			<div class="col-md-1"></div>
    			<div class="col-md-10">
                    <h4 class="text-sealbrown">Jual buku bekasmu dengan memasukkan infromasi buku berikut.</h4>
                </div>
            </div>
            <div class="row">
            	<div class="col-md-1"></div>
            	<div class="col-md-8">
            		<form action="<?= BASEURL; ?>/sell/addToMarket" method="post">
                        <div class="form-group">
                            <label for="bookTitle">Judul Buku</label>
                            <input type="text" class="form-control" id="bookTitle" name="bookTitle">
                        </div>
                        <div class="form-group">
                            <label for="bookAuthor">Penulis</label>
                            <input type="text" class="form-control" id="bookAuthor" name="bookAuthor">
                        </div>
                         <div class="form-group">
                            <label for="bookPublisher">Penerbit</label>
                            <input type="text" class="form-control" id="bookPublisher" name="bookPublisher">
                        </div>
                        <div class="form-group">
                            <label for="bookPrice">Harga</label>
                            <input type="number" class="form-control" id="bookPrice" name="bookPrice">
                        </div>
                        <button type="submit" class="btn badge-dark-tan text-celadon"><b>ADD</b></button>
                    </form>
                </div>
            </div>
        </div>
    </section>