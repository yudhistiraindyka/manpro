    <!-- Cart -->
    <section class="cart">
    	<div class="container">
    		<div class="row" style="margin-top: 30px;">
    			<div class="col-md-12">
                    <h2 class="text-sealbrown text-center">Cart</h2>
                    <hr>
                </div>
            </div>

            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <button type="button" class="btn bg-spanish-gray text-celadon border-sealbrown" data-toggle="modal" data-target="#formModal">
                        <b>Add to Cart</b>
                    </button>  
                </div>
                <div class="col-md-3"></div>
            </div>
            
            <div class="row" style="margin-top: 15px;">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <h3 class="text-sealbrown text-center">Cart List</h3>
                    <ul class="list-group">
                        <?php foreach ($data['item'] as $item) : ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?= $item['bookTitle']; ?>
                                <a href="<?= BASEURL ?>/cart/detail/<?= $item['id']; ?>" class="badge badge-dark-tan">Details</a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
    			</div>
                <div class="col-md-3"></div>
    		</div>
    	</div>

        <!-- Modal -->
        <div class="modal fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="titleOfModal" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="titleOfModal">Add to Cart</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?= BASEURL; ?>/cart/addToCart" method="post">
                            <div class="form-group">
                                <label for="bookTitle">Judul Buku</label>
                                <input type="text" class="form-control" id="bookTitle" name="bookTitle">
                            </div>
                            <div class="form-group">
                                <label for="bookAuthor">Penulis</label>
                                <input type="text" class="form-control" id="bookAuthor" name="bookAuthor">
                            </div>
                            <div class="form-group">
                                <label for="bookPublisher">Penerbit</label>
                                <input type="text" class="form-control" id="bookPublisher" name="bookPublisher">
                            </div>
                            <div class="form-group">
                                <label for="bookPrice">Harga</label>
                                <input type="number" class="form-control" id="bookPrice" name="bookPrice">
                            </div>
                    </div>
                    <div class="modal-footer d-flex justify-content-between">
                        <button type="button" class="btn bg-spanish-gray text-sealbrown" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn badge-dark-tan text-celadon"><b>ADD</b></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

   	</section>
    <!-- (Akhir) Cart -->