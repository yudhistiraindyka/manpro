<?php 

class About extends Controller {
	public function index($nama = 'Halo', $stats = 'Leader', $umur = 40)
	{
		$data['nama'] = $nama;
		$data['stats'] = $stats;
		$data['umur'] = $umur;
		$data['judul'] = 'About - Index';
		$this->view('templates/header', $data);
		$this->view('about/index', $data);
		$this->view('templates/footer');
	}

	public function page()
	{
		$data['judul'] = 'About - Page';
		$this->view('templates/header', $data);
		$this->view('about/page');
		$this->view('templates/footer');
	}
}

 ?>