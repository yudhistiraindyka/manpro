<?php 

class Home extends Controller {
	public function index()
	{
		$data['judul'] = 'Home - Index';
		$data['nama'] = $this->model('User_model')->getUser();
		$data['item'] = $this->model('Sell_model')->getAllItem();
		$this->view('templates/header', $data);
		$this->view('home/index', $data);
		$this->view('templates/footer');
	}

	public function detail($id)
	{
		$data['judul'] = 'Product Detail - Index';
		$data['item'] = $this->model('Sell_model')->getItemById($id);
		$this->view('templates/header', $data);
		$this->view('home/detail', $data);
		$this->view('templates/footer');
	}
}

?>