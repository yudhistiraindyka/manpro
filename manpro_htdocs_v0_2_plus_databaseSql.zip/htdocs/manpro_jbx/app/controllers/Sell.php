<?php 

class Sell extends Controller {
	public function index()
	{
		$data['judul'] = 'Sell Now - Index';
		$data['item'] = $this->model('Sell_model')->getAllItem();
		$this->view('templates/header', $data);
		$this->view('sell/index', $data);
		$this->view('templates/footer');
	}

	public function addToMarket()
	{
		if( $this->model('Sell_model')->addItemOnSale($_POST) > 0 ) {
			header('Location: ' . BASEURL);
			exit;
		}
	}
}

 ?>