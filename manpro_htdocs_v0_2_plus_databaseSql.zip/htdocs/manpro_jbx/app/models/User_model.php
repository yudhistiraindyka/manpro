<?php 

class User_model {
	private $nama = 'JHamzah';

	public function getUser()
	{
		return $this->nama;
	}
}

 ?>