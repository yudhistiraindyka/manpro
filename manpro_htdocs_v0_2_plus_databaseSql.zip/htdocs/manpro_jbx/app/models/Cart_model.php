<?php

class Cart_model {
	private $table = 'cart_item';
	private $db;

	public function __construct()
	{
		$this->db = new Database;
	}

	public function getAllItem()
	{
		/*$this->stmt = $this->dbh->prepare('SELECT * FROM cart_item');
		$this->stmt->execute();
		return $this->stmt->fetchAll(PDO::FETCH_ASSOC);*/
		// return $this->item;
		$this->db->query('SELECT * FROM ' . $this->table);
		return $this->db->resultSet();
	}

	public function getItemById($id)
	{
		$this->db->query('SELECT * FROM ' . $this->table . ' WHERE id=:id');
		$this->db->bind('id', $id);
		return $this->db->single();
	}

	public function addCartItem($data)
	{
		$query = "INSERT INTO cart_item
					VALUES
					('', :bookTitle, :bookAuthor, :bookPublisher, :bookPrice)";
		$this->db->query($query);
		$this->db->bind('bookTitle', $data['bookTitle']);
		$this->db->bind('bookAuthor', $data['bookAuthor']);
		$this->db->bind('bookPublisher', $data['bookPublisher']);
		$this->db->bind('bookPrice', $data['bookPrice']);

		$this->db->execute();

		return $this->db->rowCount();
	}
}

?>