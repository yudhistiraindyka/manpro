<?php 

class Login_model {
	private $table = 'users';
	private $db;

	/*
	public function __construct()
	{
		$this->db = new Database;
	}
	*/

	public function getUser($user, $password)
	{
		$con = mysqli_connect("localhost","root","","jbxmanpro");
		// $this->db->query('SELECT * FROM ' . $this->table . ' WHERE user=:user AND password=:password');
		$query = "SELECT * FROM users WHERE user=:user AND password=:password";
		/*
		$this->db->bind('user', $user);
		$this->db->bind('password', $password);
		*/
		
		$result = mysqli_query($con, $query);
	}
}

?>