<?php

class Register_model {
	private $table = 'users';
	private $db;

	public function __construct()
	{
		$this->db = new Database;
	}

	public function addUser($data)
	{
		$query = "INSERT INTO users (user, email, password)
					VALUES
					(:user, :email, :password)";
		$this->db->query($query);
		$this->db->bind('user', $data['user']);
		$this->db->bind('email', $data['email']);
		$this->db->bind('password', $data['password']);

		$this->db->execute();

		return $this->db->rowCount();
	}
}

 ?>