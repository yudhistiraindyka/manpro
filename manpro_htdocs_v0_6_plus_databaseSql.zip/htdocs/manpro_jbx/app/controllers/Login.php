<?php 

class Login extends Controller {
	public function index()
	{
		session_start();
		if (!isset($_SESSION["login"])) {
			$_SESSION['user'] = 'Login/Register';
		}
		$data['judul'] = 'Login - Index';
		$this->view('templates/header', $data);
		$this->view('login/index', $data);
		$this->view('templates/footer');
		session_destroy();
	}

	public function user()
	{
		$data['judul'] = 'User Detail - Index';
		$data['item'] = $this->model('Login_model')->getUser($data);
		$this->view('login/user', $data);
	}

	public function loginAuth()
	{
		if ( isset($_POST["login"]) ) {
			$con = mysqli_connect("localhost","root","","jbxmanpro");
			$user = $_POST["user"];
			$password = $_POST["password"];

			$user = stripcslashes($user);
			$password = stripcslashes($password);

			
			$query = "SELECT * FROM users WHERE user= '$user' AND password= '$password'";
			$result = mysqli_query($con, $query);

			$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
			
			if ( $row['user'] == $user && $row['password'] == $password ) {
				session_start();
				setcookie('user', $user);
				$_SESSION["login"] = true;
				$_SESSION['user'] = $user;
				$_SESSION['id_user'] = $row['id'];
				$data['judul'] = 'Home - Index';
				$data['masuk'] = "BERHASIL";
				$data['nama'] = $this->model('User_model')->getUser();
				$data['item'] = $this->model('Sell_model')->getAllItem();
				$this->view('login/user', $data);
				$this->view('templates/header', $data);
				$this->view('home/index', $data);

			}
			else {
				session_start();
				if (!isset($_SESSION["login"])) {
					$_SESSION['user'] = 'Login/Register';
				}
				$data['masuk'] = "GAGAL";
				$data['judul'] = 'Login - Index';
				$this->view('templates/header', $data);
				$this->view('login/index', $data);
				$this->view('login/user', $data);
			}
		}
		$this->view('templates/footer');
		
		
	}
}

?>