<?php 

class Home extends Controller {
	public function index()
	{
		session_start();
		if (!isset($_SESSION["login"])) {
			$_SESSION['user'] = 'Login/Register';
		}
		$data['judul'] = 'Home - Index';
		$data['nama'] = $this->model('User_model')->getUser();
		$data['item'] = $this->model('Sell_model')->getAllItem();
		$this->view('templates/header', $data);
		$this->view('home/index', $data);
		$this->view('templates/footer');
	}

	public function detail($id)
	{
		session_start();
		$data['judul'] = 'Product Detail - Index';
		$data['item'] = $this->model('Sell_model')->getItemById($id);
		$_SESSION['buyId'] = $id;
		//Home.addToWish.$data['bookPublisher'] = $data['item']['bookPublisher'];
		// $this->addToWish($data['item']);
		$this->view('templates/header', $data);
		$this->view('home/detail', $data);
		$this->view('templates/footer');
	}

	public function addToWish()
	{
		/*$data['item'] = $this->model('Sell_model')->getItemById($id);
		$data['bookTitle'] = $data['item']['bookTitle'];
		$data['bookPrice'] = $data['item']['bookPrice'];
		$data['bookAuthor'] = $data['item']['bookAuthor'];
		$data['bookPublisher'] = $data['item']['bookPublisher'];*/
		if( $this->model('Cart_model')->addToWishlist($_POST) > 0 ) {
			$data['wish'] = "BERHASIL";
			header('Location: ' . BASEURL . '/home/wish');
			exit;
		}
	}

	public function buy()
	{
		session_start();
		$data['judul'] = 'Product Detail - Index';
		$data['item'] = $this->model('Sell_model')->getItemById($_SESSION['buyId']);
		//Home.addToWish.$data['bookPublisher'] = $data['item']['bookPublisher'];
		// $this->addToWish($data['item']);
		$this->view('templates/header', $data);
		$this->view('home/buy', $data);
		$this->view('templates/footer');
	}

	public function addToBuy()
	{
		session_start();
		/*$data['item'] = $this->model('Sell_model')->getItemById($id);
		$data['bookTitle'] = $data['item']['bookTitle'];
		$data['bookPrice'] = $data['item']['bookPrice'];
		$data['bookAuthor'] = $data['item']['bookAuthor'];
		$data['bookPublisher'] = $data['item']['bookPublisher'];*/
		$_POST['id_user'] = $_SESSION['id_user'];
		if( $this->model('Sell_model')->addToBuy($_POST) > 0 ) {
			$data['wish'] = "BERHASIL";
			header('Location: ' . BASEURL . '/home/wish');
			exit;
		}
	}
}

?>