    <!-- Login -->
    <!-- <section class="login">
      <div class="container">
        <div class="row" style="margin-top: 30px;">
          <div class="col-md-12">
            <h2 class="text-sealbrown text-center">Login</h2>
            <hr>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="col-md-4">
            <p class="card-title"><?= $data['masuk']; ?></p>
          </div>
        </div>
      </div>
    </section> -->
    <!-- (Akhir) Login -->
    	<div class="row badge-dark-tan" style="padding-top: 15px;">
    		<div class="col-md-4"></div>
    		<div class="col-md-4">
    			<p class="card-title text-celadon text-center"><b>LOGIN <?= $data['masuk']; ?></b></p>
    		</div>
    	</div>