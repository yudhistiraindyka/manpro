    <!-- <h1>Index Page</h1>
    <p>My Name is <?= $data['nama']; ?>. Is <?= $data['stats']; ?>. Age <?= $data['umur']; ?>. </p> -->	

    <!-- about -->
    <section class="about border-bottom border-sealbrown" id="about">
      <div class="container">
        
        <div class="row">
          <div class="col-md-12">
            <h2 class="text-sealbrown text-center">About</h2>
            <hr>
          </div>
        </div>
        
        <div class="row" style="padding-bottom: 15px;">
          <div class="col-md-2"></div>
          <div class="col-md-8 text-center">
            We build the bridge to anyone who are looking for second-hand books and to those who want to have some bucks from old books they have.
          </div>
          <div class="col-md-2"></div>
        </div>

        <div class="row" style="padding-bottom: 15px;">
          <div class="col-md-2"></div>
          <div class="col-md-8 text-center">
            We keep monitoring the interaction between buyer and seller during the transaction period so they can put the trust to each other and to our paltform.
          </div>
          <div class="col-md-2"></div>
        </div>

        <div class="row" style="padding-bottom: 15px;">
          <div class="col-md-2"></div>
          <div class="col-md-8 text-center">
            If you have any problem facing our platform, please send complaints in below section in this page or any of this web's page else.
          </div>
          <div class="col-md-2"></div>
        </div>

      </div>
    </section>
    <!-- (Akhir)  about -->