<?php

class Sell_model {
	private $table = 'on_sale';
	private $db;

	public function __construct()
	{
		$this->db = new Database;
	}

	public function getAllItem()
	{
		/*$this->stmt = $this->dbh->prepare('SELECT * FROM on_sale');
		$this->stmt->execute();
		return $this->stmt->fetchAll(PDO::FETCH_ASSOC);*/
		// return $this->item;
		$this->db->query('SELECT * FROM ' . $this->table);
		return $this->db->resultSet();
	}

	public function getItemById($id)
	{
		$this->db->query('SELECT * FROM ' . $this->table . ' WHERE id=:id');
		$this->db->bind('id', $id);
		return $this->db->single();
	}

	public function addItemOnSale($data)
	{
		$query = "INSERT INTO on_sale
					VALUES
					('', :bookTitle, :bookAuthor, :bookPublisher, :bookPrice)";
		$this->db->query($query);
		$this->db->bind('bookTitle', $data['bookTitle']);
		$this->db->bind('bookAuthor', $data['bookAuthor']);
		$this->db->bind('bookPublisher', $data['bookPublisher']);
		$this->db->bind('bookPrice', $data['bookPrice']);

		$this->db->execute();

		return $this->db->rowCount();
	}

	public function addToBuy($data)
	{
		$query = "INSERT INTO item_buy
					VALUES
					('', :bookTitle, :bookAuthor, :bookPublisher, :bookPrice, :userId)";
		$this->db->query($query);
		$this->db->bind('bookTitle', $_POST['bookTitle']);
		$this->db->bind('bookAuthor', $_POST['bookAuthor']);
		$this->db->bind('bookPublisher', $_POST['bookPublisher']);
		$this->db->bind('bookPrice', $_POST['bookPrice']);
		$this->db->bind('userId', $_POST['id_user']);

		$this->db->execute();

		return $this->db->rowCount();
	}
}

?>