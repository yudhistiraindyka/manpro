<?php

class Buy_model {
	private $table = 'item_buy';
	private $db;

	public function __construct()
	{
		$this->db = new Database;
	}

	public function getAllItem()
	{
		/*$this->stmt = $this->dbh->prepare('SELECT * FROM cart_item');
		$this->stmt->execute();
		return $this->stmt->fetchAll(PDO::FETCH_ASSOC);*/
		// return $this->item;
		$this->db->query('SELECT * FROM ' . $this->table);
		return $this->db->resultSet();
	}

}


?>