    <!-- Cart -->
    <section class="cart">
    	<div class="container">
    		<div class="row" style="margin-top: 30px;">
    			<div class="col-md-12">
                    <h2 class="text-sealbrown text-center">Book(s) Bought</h2>
                    <hr>
                </div>
            </div>

            <div class="row">
            </div>
            
            <div class="row" style="margin-top: 15px;">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <h3 class="text-sealbrown text-center">Buying List</h3>
                    <ul class="list-group">
                        <?php foreach ($data['item'] as $item) : ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?= $item['bookTitle']; ?>
                                
                            </li>
                        <?php endforeach; ?>
                    </ul>
    			</div>
                <div class="col-md-3"></div>
    		</div>
    	</div>

   	</section>
    <!-- (Akhir) Cart -->