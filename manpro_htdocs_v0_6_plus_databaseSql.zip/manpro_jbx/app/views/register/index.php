    <!-- Login -->
    <section class="login">
      <div class="container">
        <div class="row" style="margin-top: 30px;">
          <div class="col-md-12">
            <h2 class="text-sealbrown text-center">Register</h2>
            <hr>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="col-md-4">
            <form action="<?= BASEURL; ?>/register/registerAuth" method="post">
              <div class="form-group">
                <input type="text" class="form-control" name="user" placeholder="username" id="user">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="email" placeholder="email" id="email">
              </div>
              <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="password" id="password">
              </div>
              <button type="submit" class="btn btn-normal" name="login">Submit</button>
            </form>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="col-md-4 text-center">
            <a href="<?= BASEURL; ?>/login"><p class="text-sealbrown">Click to Login</p></a>
          </div>
        </div>
      </div>
    </section>
    <!-- (Akhir) Login -->
	