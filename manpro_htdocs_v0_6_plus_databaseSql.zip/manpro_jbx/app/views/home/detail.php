    <!-- portfolio -->
    <section class="portfolio" id="portfolio">
      <div class="container">
        
        <div class="row">
          <div class="col-md-12 text-left">
            <h2 class="text-sealbrown">Product Details <!-- by <?= $data['nama']; ?> --></h2>
          </div>
        </div>

        <div class="row" style="margin-top: 30px;">
          
          <!-- <div class="col-md-1"></div> -->
          <div class="col-md-3">
              <img src="<?= BASEURL; ?>/img/Transparent.png" class="preframe bg-dark-tan" style="width: 16rem; padding-bottom: 60px;">
          </div>
          <div class="col-md-3">
            <div class="container">
              <form action="<?= BASEURL; ?>/home/addToWish" method="post">
              <h5>Judul Buku<input class="card-title" id="bookTitle" name="bookTitle" value="<?= $data['item']['bookTitle']; ?>"></h5>
              <h6><h6>Harga</h6>Rp<input class="card-subtitle mb-2" id="bookPrice" name="bookPrice" value="<?= $data['item']['bookPrice']; ?>"></h6>
              <p>Author: <input class="card-text" id="bookAuthor" name="bookAuthor" value="<?= $data['item']['bookAuthor']; ?>"></p>
              <p>Publisher: <input class="card-text" id="bookPublisher" name="bookPublisher" style="margin-top: -15px;" value="<?= $data['item']['bookPublisher']; ?>"></p>
              <a href=" <?= BASEURL; ?>/home" class="btn bg-spanish-gray text-celadon"><i class="fas fa-long-arrow-alt-left"></i> Back</a>
            </div>
          </div>
          <div class="col-md-2">
            <a href=" <?= BASEURL; ?>/home/buy" class="btn bg-dark-tan text-celadon" style="width: 10rem;"><h3>BUY</h3></a>
          </div>
          <div class="col-md-2">
            <button type="submit" class="btn bg-dark-tan text-celadon" style="width: 10rem;"><h3>+ Wishlist</h3></button>
          </div>
          </form>
        </div>

      </div>
    </section>
    <!-- (Akhir) portfolio -->