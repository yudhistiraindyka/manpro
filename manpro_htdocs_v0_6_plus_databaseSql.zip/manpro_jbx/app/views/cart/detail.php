    <!-- Cart Detail-->
    <section class="cart">
    	<div class="container">
    		<div class="row" style="margin-top: 30px;">
    			<div class="col-md-12">
    				<h2 class="text-sealbrown text-center">Cart</h2>
                    <hr>
                </div>
            </div>
    		<div class="row">
    			<div class="col-md-3"></div>
    			<div class="col-md-6">
    				<h3 class="text-sealbrown">Cart Item Details</h3>
                </div>
                <div class="col-md-3"></div>
            </div>
            <div class="row">
            	<div class="col-md-3"></div>
            	<div class="col-md-6">
				    <div class="card d-flex justify-content-between align-items-center">
				    	<div class="card-body">
				    		<h5 class="card-title"><?= $data['item']['bookTitle']; ?></h5>
				    		<h6 class="card-subtitle mb-2">Rp<?= $data['item']['bookPrice']; ?></h6>
				    		<p class="card-text">Author: <?= $data['item']['bookAuthor']; ?></p>
				    		<p class="card-text">Publisher: <?= $data['item']['bookPublisher']; ?></p>
				    		<a href=" <?= BASEURL; ?>/home/buy" class="btn bg-dark-tan text-celadon" style="width: 5rem; margin-bottom: 15px;"><h3>BUY</h3></a>
                            <p><a href=" <?= BASEURL; ?>/cart" class="card-link">Back to the Cart</a></p>
				    	</div>
				    </div>
			    </div>
			    <div class="col-md-3"></div>
    		</div>
    	</div>
   	</section>
    <!-- (Akhir) Cart Detail-->