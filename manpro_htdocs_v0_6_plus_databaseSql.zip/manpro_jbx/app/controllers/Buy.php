<?php 

class Buy extends Controller {
	public function index()
	{
		session_start();
		if (!isset($_SESSION["login"])) {
			header('Location: ' . BASEURL . '/login');
			# code...
		}
		$data['judul'] = 'Bought Item - Index';
		$user = $_SESSION['id_user'];
		$data['item'] = $this->model('Buy_model')->getAllItem();
		$this->view('templates/header', $data);
		$this->view('buy/index', $data);
		$this->view('templates/footer');
		
	}
}

?>