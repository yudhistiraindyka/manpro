<?php 

class Cart extends Controller {
	public function index()
	{
		session_start();
		if (!isset($_SESSION["login"])) {
			header('Location: ' . BASEURL . '/login');
			# code...
		}
		$data['judul'] = 'Wish List - Index';
		$data['item'] = $this->model('Cart_model')->getAllItem();
		$this->view('templates/header', $data);
		$this->view('cart/index', $data);
		$this->view('templates/footer');
		
	}

	public function detail($id)
	{
		session_start();
		if (!isset($_SESSION["login"])) {
			$_SESSION['user'] = 'Login/Register';
		}
		$data['judul'] = 'Detail Cart - Index';
		$data['item'] = $this->model('Cart_model')->getItemById($id);
		$this->view('templates/header', $data);
		$this->view('cart/detail', $data);
		$this->view('templates/footer');
	}

	public function addToCart()
	{
		if( $this->model('Cart_model')->addCartItem($_POST) > 0 ) {
			header('Location: ' . BASEURL . '/cart');
			exit;
		}
	}
}

 ?>