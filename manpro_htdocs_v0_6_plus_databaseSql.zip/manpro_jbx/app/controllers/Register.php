<?php

class Register extends Controller {
	public function index()
	{
		if (!isset($_SESSION["login"])) {
			$_SESSION['user'] = 'Login/Register';
		}
		$data['judul'] = 'Register - Index';
		$this->view('templates/header', $data);
		$this->view('register/index', $data);
		$this->view('templates/footer');
	}

	public function registerAuth()
	{
		if( $this->model('Register_model')->addUser($_POST) > 0 ) {
			$data['masuk'] = "BERHASIL";
			$this->view('register/user', $data);
			header('Location: ' . BASEURL);
			exit;
			/*$this->view('templates/header', $data);
			$this->view('home/index', $data);
			$this->view('templates/footer');*/
		}
	}
}

?>