    <!-- contact -->
    <section class="contact bg-dark-tan">
      <div class="container" style="min-height: 200px; padding-top: 15px; padding-bottom: 45px;">
        <div class="row">
          <div class="col-md-9"></div>
          <div class="col-md-3">
            <h3 class="text-celadon" style="padding-bottom: 15px;">Complaints</h3>
            <form>
              <div class="form-group">
                <input type="text" id="nama" class="form-control" placeholder="Nama">
              </div>
              <div class="form-group">
                <input type="email" id="email" class="form-control" placeholder="Email">
              </div>
              <div class="form-group">
                <textarea class="form-control" rows="5" placeholder="Masukkan keluhan"></textarea>
              </div>
              <button class="btn btn-normal">Send</button>
            </form>
          </div>
        </div>
      </div>
    </section>
    <!-- (Akhir) contact -->

    <!-- footer -->
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-celadon text-center">
            <p>Copyright 2020 <i class="fab fa-accessible-icon"></i></p>
          </div>
        </div>
      </div>
    </footer>
    <!-- (Akhir) footer -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="<?= BASEURL; ?>/js/jquery-3.4.1.min.js"></script>

	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>