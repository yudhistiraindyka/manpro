    <!-- portfolio -->
    <section class="portfolio" id="portfolio">
      <div class="container">
        
        <div class="row">
          <div class="col-md-12 text-left">
            <h2 class="text-sealbrown">Product Details <!-- by <?= $data['nama']; ?> --></h2>
          </div>
        </div>

        <div class="row" style="margin-top: 30px;">
          <!-- <div class="col-md-1"></div> -->
          <div class="col-md-3">
              <img src="<?= BASEURL; ?>/img/Transparent.png" class="preframe bg-dark-tan" style="width: 16rem; padding-bottom: 60px;">
          </div>
          <div class="col-md-3">
            <div class="container">
              <h5 class="card-title"><?= $data['item']['bookTitle']; ?></h5>
              <h6 class="card-subtitle mb-2">Rp<?= $data['item']['bookPrice']; ?></h6>
              <p class="card-text">Author: <?= $data['item']['bookAuthor']; ?></p>
              <p class="card-text" style="margin-top: -15px;">Publisher: <?= $data['item']['bookPublisher']; ?></p>
              <a href=" <?= BASEURL; ?>/home" class="btn bg-spanish-gray text-celadon"><i class="fas fa-long-arrow-alt-left"></i> Back</a>
            </div>
          </div>
          <div class="col-md-2">
            <a href=" <?= BASEURL; ?>/home" class="btn bg-dark-tan text-celadon" style="width: 10rem;"><h3>BUY</h3></a>
          </div>
          <div class="col-md-2">
            <a href=" <?= BASEURL; ?>/home" class="btn bg-dark-tan text-celadon" style="width: 10rem;"><h3>+ Wishlist</h3></a>
          </div>
        </div>
        
        <!--
        <div class="row" style="margin-top: 30px;">
          
          <div class="col-md-3" style="margin-bottom: 15px;">
           <a href="" class="card bg-dark-tan text-celadon border-sealbrown" style="width: 16rem;">
             <img src="<?= BASEURL; ?>/img/Picture4.png" class="card-img-top" style="max-height: 17rem;">
             <div class="card-body">The Strangers</div>
           </a> 
          </div>

          <div class="col-md-3" style="margin-bottom: 15px;">
           <a href="" class="card bg-dark-tan text-celadon border-sealbrown" style="width: 16rem;">
             <img src="<?= BASEURL; ?>/img/Picture7.png" class="card-img-top">
             <div class="card-body">Leafy</div>
           </a> 
          </div>

        </div>
        -->
      </div>
    </section>
    <!-- (Akhir) portfolio -->